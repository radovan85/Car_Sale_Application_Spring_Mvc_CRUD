package com.radovan.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.radovan.demo.entity.CarEntity;

@Repository
public interface CarRepository extends JpaRepository<CarEntity, Integer>{

	@Query(value = "select * from cars where brand like %:keyword% "
			+ "or model like %:keyword% "
			+ "or color like %:keyword%",nativeQuery = true)
	List<CarEntity> search(@Param("keyword") String keyword);

}
