package com.radovan.demo.service;

import java.util.List;

import com.radovan.demo.entity.CarEntity;

public interface CarService {

	CarEntity addCar(CarEntity car);
	
	CarEntity updateCar(int id);
	
	CarEntity getCar(int id);
	
	void deleteCar(int id);
	
	List<CarEntity> listAll();
	
	List<CarEntity> search(String keyword);
}
