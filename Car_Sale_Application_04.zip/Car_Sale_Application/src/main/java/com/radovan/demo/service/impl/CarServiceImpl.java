package com.radovan.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.radovan.demo.entity.CarEntity;
import com.radovan.demo.repository.CarRepository;
import com.radovan.demo.service.CarService;

@Service
@Transactional
public class CarServiceImpl implements CarService{
	
	@Autowired
	private CarRepository carRepository;

	@Override
	public CarEntity addCar(CarEntity car) {
		// TODO Auto-generated method stub
		CarEntity returnValue = carRepository.save(car);
		return returnValue;
	}

	@Override
	public CarEntity updateCar(int id) {
		// TODO Auto-generated method stub
		CarEntity car = getCar(id);
		CarEntity returnValue = carRepository.saveAndFlush(car);
		return returnValue;
	}

	@Override
	public CarEntity getCar(int id) {
		// TODO Auto-generated method stub
		CarEntity returnValue = carRepository.findById(id).get();
		return returnValue;
	}

	@Override
	public void deleteCar(int id) {
		// TODO Auto-generated method stub
		carRepository.deleteById(id);
	}

	@Override
	public List<CarEntity> listAll() {
		// TODO Auto-generated method stub
		List<CarEntity> returnValue = carRepository.findAll();
		return returnValue;
	}

	@Override
	public List<CarEntity> search(String keyword) {
		// TODO Auto-generated method stub
		List<CarEntity> returnValue = carRepository.search(keyword);
		return returnValue;
	}

}
