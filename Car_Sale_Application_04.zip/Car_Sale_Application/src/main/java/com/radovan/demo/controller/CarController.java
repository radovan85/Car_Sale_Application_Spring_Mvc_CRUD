package com.radovan.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.radovan.demo.entity.CarEntity;
import com.radovan.demo.service.CarService;

@Controller
public class CarController {

	@Autowired
	private CarService carService;

	@GetMapping(value = "/")
	public String indexPage() {
		return "index";
	}

	@RequestMapping(value = "/newCar", method = RequestMethod.GET)
	public String newCar(ModelMap map) {

		CarEntity car = new CarEntity();
		map.put("car", car);
		return "car_form";
	}

	@PostMapping(value = "/saveCar")
	// same purpose
	// @RequestMapping(value = "/saveCar",method = RequestMethod.POST)
	public String saveCar(@Validated @ModelAttribute("car") CarEntity car, Errors errors, ModelMap map) {

		if (errors.hasErrors()) {
			return "car_form";
		}

		carService.addCar(car);
		return "redirect:/allCars";
	}

	@RequestMapping(value = "/updateCar", method = RequestMethod.GET)
	public String updateCar(@RequestParam("carId") int carId, ModelMap map) {

		CarEntity car = carService.getCar(carId);
		map.put("car", car);
		carService.updateCar(car.getId());
		return "car_form";
	}

	@GetMapping(value = "/deleteCar")
	public String deleteCar(@RequestParam("carId") int carId) {

		carService.deleteCar(carId);
		return "redirect:/allCars";
	}

	@RequestMapping(value = "/allCars", method = RequestMethod.GET)
	public String listAllCars(ModelMap map) {

		List<CarEntity> allCarsList = carService.listAll();
		map.put("allCarsList", allCarsList);
		return "cars_list";
	}

	@RequestMapping(value = "/searchCars", method = RequestMethod.GET)
	public String searchCars(@RequestParam("keyword") String keyword, ModelMap map) {

		List<CarEntity> listResult = carService.search(keyword);
		map.put("listResult", listResult);
		return "cars_search";
	}

}
